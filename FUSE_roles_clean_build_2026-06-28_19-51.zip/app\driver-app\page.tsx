﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { collection, doc, onSnapshot, orderBy, query, serverTimestamp, updateDoc, addDoc } from "firebase/firestore";
import { db } from "../firebase";
import {
  FUSE_COOKIE_EMAIL,
  FUSE_COOKIE_NAME,
  FUSE_COOKIE_PHONE,
  FUSE_COOKIE_RESTAURANT,
  FUSE_COOKIE_ROLE,
  FUSE_LOCAL_SESSION,
  parseFuseRole,
  roleHome,
  roleTitle,
  type FuseSession,
} from "@/lib/fuse-auth";

type OrderDoc = {
  documentId: string;
  orderId?: string;
  customerName?: string;
  customer?: string;
  name?: string;
  phone?: string;
  customerPhone?: string;
  address?: string;
  restaurant?: string;
  restaurantName?: string;
  total?: number;
  amount?: number;
  status?: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  createdAt?: unknown;
};

type DriverDoc = {
  documentId: string;
  name?: string;
  driverName?: string;
  phone?: string;
  driverPhone?: string;
  email?: string;
  status?: string;
  online?: boolean;
  isOnline?: boolean;
  rating?: number;
};

function clearCookie(name: string) {
  document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax`;
}

function readSession(): FuseSession | null {
  try {
    const raw = localStorage.getItem(FUSE_LOCAL_SESSION);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as FuseSession;
    const role = parseFuseRole(parsed.role);
    if (!parsed.email || !role) return null;
    return { ...parsed, role };
  } catch {
    return null;
  }
}

function cleanPhone(value?: string) {
  return (value || "").replace(/\D/g, "");
}

function normalizeStatus(status?: string) {
  if (!status) return "جديد";
  if (status === "جاهز") return "جاهز للتوصيل";
  if (status === "السائق استلم") return "قيد التوصيل";
  return status;
}

function toDate(value: unknown): Date | null {
  try {
    if (!value) return null;
    if (typeof value === "object" && value !== null && "toDate" in value && typeof (value as { toDate?: unknown }).toDate === "function") {
      return (value as { toDate: () => Date }).toDate();
    }
    if (value instanceof Date) return value;
    const date = new Date(value as string | number);
    return Number.isNaN(date.getTime()) ? null : date;
  } catch {
    return null;
  }
}

function formatDate(value: unknown) {
  const date = toDate(value);
  if (!date) return "بدون وقت";
  return date.toLocaleString("ar-IQ", {
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function getRestaurant(order: OrderDoc) {
  return order.restaurant || order.restaurantName || "مطعم";
}

function getCustomer(order: OrderDoc) {
  return order.customerName || order.customer || order.name || "زبون";
}

function getCustomerPhone(order: OrderDoc) {
  return order.phone || order.customerPhone || "";
}

function getTotal(order: OrderDoc) {
  return Number(order.total || order.amount || 0);
}

function getDriverName(driver?: DriverDoc | null) {
  if (!driver) return "";
  return driver.name || driver.driverName || "سائق";
}

function getDriverPhone(driver?: DriverDoc | null) {
  if (!driver) return "";
  return driver.phone || driver.driverPhone || "";
}

function driverOnline(driver?: DriverDoc | null) {
  if (!driver) return false;
  return driver.online === true || driver.isOnline === true || driver.status === "متصل";
}

function orderBelongsToDriver(order: OrderDoc, session: FuseSession | null, driver: DriverDoc | null) {
  const sessionPhone = cleanPhone(session?.phone);
  const driverPhone = cleanPhone(getDriverPhone(driver));
  const orderDriverPhone = cleanPhone(order.driverPhone);

  if (driver?.documentId && order.driverId === driver.documentId) return true;
  if (order.driverName && session?.name && order.driverName === session.name) return true;
  if (order.driverName && driver && order.driverName === getDriverName(driver)) return true;
  if (orderDriverPhone && sessionPhone && orderDriverPhone.includes(sessionPhone)) return true;
  if (orderDriverPhone && driverPhone && orderDriverPhone.includes(driverPhone)) return true;

  return false;
}

function isActiveOrder(order: OrderDoc) {
  const status = normalizeStatus(order.status);
  return status !== "تم التسليم" && status !== "مرفوض";
}

function canPickup(order: OrderDoc) {
  const status = normalizeStatus(order.status);
  return status === "جاهز للتوصيل" || status === "جديد";
}

function statusBadgeStyle(status?: string): CSSProperties {
  const clean = normalizeStatus(status);
  if (clean === "جديد") return styles.badgeOrange;
  if (clean === "قيد التحضير") return styles.badgeYellow;
  if (clean === "جاهز للتوصيل") return styles.badgeSky;
  if (clean === "قيد التوصيل") return styles.badgePurple;
  if (clean === "تم التسليم") return styles.badgeGreen;
  if (clean === "مرفوض") return styles.badgeRed;
  return styles.badgeMuted;
}

const styles: Record<string, CSSProperties> = {
  page: {
    minHeight: "100vh",
    background: "radial-gradient(circle at top right, rgba(255,122,0,0.16), transparent 34%), #050505",
    color: "white",
    padding: "26px 16px",
    fontFamily: "Arial, sans-serif",
  },
  shell: { width: "100%", maxWidth: 1180, margin: "0 auto" },
  topBar: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", marginBottom: 16 },
  nav: { display: "flex", gap: 10, flexWrap: "wrap" },
  pill: {
    border: "1px solid rgba(255,255,255,0.13)",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    padding: "11px 16px",
    color: "rgba(255,255,255,0.82)",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 900,
  },
  activePill: {
    border: "1px solid rgba(255,122,0,0.35)",
    borderRadius: 999,
    background: "#FF7A00",
    padding: "11px 16px",
    color: "#000",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 950,
  },
  logout: {
    border: "1px solid rgba(239,68,68,0.32)",
    borderRadius: 999,
    background: "rgba(239,68,68,0.10)",
    color: "#FECACA",
    padding: "11px 16px",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 950,
  },
  hero: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 34,
    background: "linear-gradient(135deg, rgba(255,255,255,0.075), rgba(255,122,0,0.10))",
    boxShadow: "0 24px 70px rgba(0,0,0,0.45)",
    padding: 22,
    marginBottom: 16,
  },
  heroGrid: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) repeat(4, minmax(150px, 0.32fr))",
    gap: 12,
    alignItems: "stretch",
  },
  card: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.36)",
    padding: 20,
  },
  compactCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 24,
    background: "rgba(0,0,0,0.34)",
    padding: 16,
    minHeight: 118,
  },
  eyebrow: { margin: 0, color: "#FF7A00", fontSize: 13, fontWeight: 950 },
  title: { margin: "8px 0 0", fontSize: "clamp(36px, 5vw, 60px)", lineHeight: 1.08, fontWeight: 950 },
  orange: { color: "#FF7A00" },
  muted: { color: "rgba(255,255,255,0.58)", lineHeight: 1.85, fontSize: 14 },
  statLabel: { margin: 0, color: "rgba(255,255,255,0.52)", fontSize: 13, fontWeight: 850 },
  statValue: { margin: "10px 0 0", fontSize: 30, fontWeight: 950 },
  panelGrid: { display: "grid", gridTemplateColumns: "minmax(260px, 0.38fr) minmax(0, 1fr)", gap: 14, marginBottom: 16 },
  panel: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 30,
    background: "rgba(255,255,255,0.045)",
    padding: 18,
  },
  sectionTitle: { margin: 0, fontSize: 24, fontWeight: 950 },
  driverBox: {
    border: "1px solid rgba(255,122,0,0.22)",
    borderRadius: 24,
    background: "rgba(255,122,0,0.08)",
    padding: 16,
    marginTop: 14,
  },
  statusButton: {
    width: "100%",
    border: 0,
    borderRadius: 18,
    background: "#FF7A00",
    color: "#000",
    padding: "15px 16px",
    cursor: "pointer",
    fontSize: 14,
    fontWeight: 950,
    marginTop: 14,
  },
  offlineButton: {
    width: "100%",
    border: "1px solid rgba(239,68,68,0.32)",
    borderRadius: 18,
    background: "rgba(239,68,68,0.10)",
    color: "#FECACA",
    padding: "15px 16px",
    cursor: "pointer",
    fontSize: 14,
    fontWeight: 950,
    marginTop: 10,
  },
  disabledButton: {
    width: "100%",
    border: 0,
    borderRadius: 18,
    background: "rgba(255,255,255,0.09)",
    color: "rgba(255,255,255,0.35)",
    padding: "15px 16px",
    fontSize: 14,
    fontWeight: 950,
    marginTop: 14,
  },
  ordersGrid: { display: "grid", gap: 12, marginTop: 14 },
  orderCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.30)",
    padding: 16,
  },
  orderTop: { display: "grid", gridTemplateColumns: "minmax(220px, 1fr) minmax(180px, 0.38fr)", gap: 12, alignItems: "start" },
  totalBox: {
    border: "1px solid rgba(255,122,0,0.22)",
    borderRadius: 22,
    background: "rgba(255,122,0,0.08)",
    padding: 14,
  },
  infoGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10, marginTop: 14 },
  infoBox: {
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 16,
    background: "rgba(255,255,255,0.04)",
    padding: 10,
  },
  orderActions: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 10, marginTop: 14 },
  badge: {
    display: "inline-flex",
    alignItems: "center",
    border: "1px solid",
    borderRadius: 999,
    padding: "7px 11px",
    fontSize: 12,
    fontWeight: 950,
  },
  badgeOrange: { borderColor: "rgba(255,122,0,0.42)", background: "rgba(255,122,0,0.12)", color: "#FFB56B" },
  badgeYellow: { borderColor: "rgba(234,179,8,0.42)", background: "rgba(234,179,8,0.12)", color: "#FDE68A" },
  badgeSky: { borderColor: "rgba(14,165,233,0.42)", background: "rgba(14,165,233,0.12)", color: "#7DD3FC" },
  badgePurple: { borderColor: "rgba(168,85,247,0.42)", background: "rgba(168,85,247,0.12)", color: "#D8B4FE" },
  badgeGreen: { borderColor: "rgba(34,197,94,0.42)", background: "rgba(34,197,94,0.12)", color: "#86EFAC" },
  badgeRed: { borderColor: "rgba(239,68,68,0.42)", background: "rgba(239,68,68,0.12)", color: "#FCA5A5" },
  badgeMuted: { borderColor: "rgba(255,255,255,0.14)", background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.65)" },
  messageOk: {
    border: "1px solid rgba(34,197,94,0.30)",
    borderRadius: 18,
    background: "rgba(34,197,94,0.10)",
    color: "#86EFAC",
    padding: 14,
    marginTop: 14,
    fontSize: 14,
    fontWeight: 900,
  },
  messageBad: {
    border: "1px solid rgba(239,68,68,0.30)",
    borderRadius: 18,
    background: "rgba(239,68,68,0.10)",
    color: "#FCA5A5",
    padding: 14,
    marginTop: 14,
    fontSize: 14,
    fontWeight: 900,
  },
  empty: {
    border: "1px dashed rgba(255,255,255,0.16)",
    borderRadius: 24,
    background: "rgba(255,255,255,0.035)",
    padding: 24,
    textAlign: "center",
  },
};

export default function DriverAppPage() {
  const [session, setSession] = useState<FuseSession | null>(null);
  const [orders, setOrders] = useState<OrderDoc[]>([]);
  const [drivers, setDrivers] = useState<DriverDoc[]>([]);
  const [saving, setSaving] = useState(false);
  const [savingOrderId, setSavingOrderId] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const saved = readSession();

    if (!saved) {
      window.location.href = "/login?next=/driver-app";
      return;
    }

    if (saved.role !== "admin" && saved.role !== "driver") {
      window.location.href = roleHome[saved.role] || "/live-orders";
      return;
    }

    setSession(saved);
  }, []);

  useEffect(() => {
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((item) => ({
          ...(item.data() as Omit<OrderDoc, "documentId">),
          documentId: item.id,
        }));

        setOrders(data);
      },
      (snapshotError) => setError(snapshotError.message || "تعذر تحميل الطلبات")
    );

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, "drivers"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((item) => ({
          ...(item.data() as Omit<DriverDoc, "documentId">),
          documentId: item.id,
        }));

        setDrivers(data);
      },
      () => setDrivers([])
    );

    return () => unsubscribe();
  }, []);

  const role = session?.role || null;

  const currentDriver = useMemo(() => {
    if (!session) return null;
    const sessionPhone = cleanPhone(session.phone);

    return (
      drivers.find((driver) => {
        const driverPhone = cleanPhone(getDriverPhone(driver));
        const driverName = getDriverName(driver);
        const samePhone = driverPhone && sessionPhone && driverPhone.includes(sessionPhone);
        const sameName = driverName && driverName === session.name;
        const sameEmail = driver.email && driver.email === session.email;
        return samePhone || sameName || sameEmail;
      }) || null
    );
  }, [drivers, session]);

  const myOrders = useMemo(() => {
    if (!session) return [];
    if (role === "admin") return orders.filter((order) => order.driverName || order.driverId).filter(isActiveOrder);
    return orders.filter((order) => orderBelongsToDriver(order, session, currentDriver)).filter(isActiveOrder);
  }, [currentDriver, orders, role, session]);

  const deliveredToday = useMemo(() => {
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);

    return orders.filter((order) => {
      const date = toDate(order.createdAt);
      if (!date || date < start) return false;
      if (role === "admin") return normalizeStatus(order.status) === "تم التسليم" && (order.driverName || order.driverId);
      return normalizeStatus(order.status) === "تم التسليم" && orderBelongsToDriver(order, session, currentDriver);
    });
  }, [currentDriver, orders, role, session]);

  const readyOrders = orders.filter((order) => canPickup(order) && !order.driverName && !order.driverId);
  const onDeliveryOrders = myOrders.filter((order) => normalizeStatus(order.status) === "قيد التوصيل");
  const earningsToday = deliveredToday.reduce((sum, order) => sum + Math.round(getTotal(order) * 0.12), 0);

  async function upsertDriverStatus(online: boolean) {
    setSaving(true);
    setMessage("");
    setError("");

    try {
      if (currentDriver) {
        await updateDoc(doc(db, "drivers", currentDriver.documentId), {
          online,
          isOnline: online,
          status: online ? "متصل" : "غير متصل",
          lastSeen: serverTimestamp(),
          name: getDriverName(currentDriver) || session?.name || "سائق FUSE",
          phone: getDriverPhone(currentDriver) || session?.phone || "",
        });
      } else {
        await addDoc(collection(db, "drivers"), {
          name: session?.name || "سائق FUSE",
          phone: session?.phone || "",
          email: session?.email || "",
          online,
          isOnline: online,
          status: online ? "متصل" : "غير متصل",
          rating: 4.8,
          currentOrders: 0,
          activeOrders: 0,
          area: "بغداد",
          lastSeen: serverTimestamp(),
        });
      }

      setMessage(online ? "تم تفعيل السائق كمتصل." : "تم تحويل السائق إلى غير متصل.");
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "تعذر تحديث حالة السائق");
    } finally {
      setSaving(false);
    }
  }

  async function updateOrder(order: OrderDoc, nextStatus: string) {
    setSavingOrderId(order.documentId);
    setMessage("");
    setError("");

    try {
      await updateDoc(doc(db, "orders", order.documentId), {
        status: nextStatus,
        driverId: currentDriver?.documentId || order.driverId || "",
        driverName: currentDriver ? getDriverName(currentDriver) : session?.name || order.driverName || "سائق FUSE",
        driverPhone: currentDriver ? getDriverPhone(currentDriver) : session?.phone || order.driverPhone || "",
        driverUpdatedAt: serverTimestamp(),
      });

      setMessage(`تم تحديث الطلب إلى: ${nextStatus}`);
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "تعذر تحديث الطلب");
    } finally {
      setSavingOrderId("");
    }
  }

  function logout() {
    localStorage.removeItem(FUSE_LOCAL_SESSION);
    clearCookie(FUSE_COOKIE_ROLE);
    clearCookie(FUSE_COOKIE_EMAIL);
    clearCookie(FUSE_COOKIE_NAME);
    clearCookie(FUSE_COOKIE_PHONE);
    clearCookie(FUSE_COOKIE_RESTAURANT);
    window.location.href = "/login";
  }

  return (
    <main dir="rtl" style={styles.page}>
      <section style={styles.shell}>
        <header style={styles.topBar}>
          <nav style={styles.nav}>
            <Link href="/" style={styles.pill}>الرئيسية</Link>
            <Link href="/driver-app" style={styles.activePill}>تطبيق السائق</Link>
            <Link href="/live-orders" style={styles.pill}>الطلبات المباشرة</Link>
            {role === "admin" ? <Link href="/drivers-admin" style={styles.pill}>إدارة السائقين</Link> : null}
          </nav>
          <button onClick={logout} style={styles.logout}>خروج</button>
        </header>

        <section style={styles.hero}>
          <div style={styles.heroGrid}>
            <div style={styles.card}>
              <p style={styles.eyebrow}>تطبيق السائق</p>
              <h1 style={styles.title}>
                طلباتك
                <br />
                <span style={styles.orange}>والحالة المباشرة</span>
              </h1>
              <p style={styles.muted}>
                السائق يشوف الطلبات المرتبطة بيه، يغيّر حالته، ويحدّث الطلب من الاستلام إلى التسليم.
              </p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>الدور</p>
              <p style={{ ...styles.statValue, ...styles.orange }}>{role ? roleTitle[role] : "—"}</p>
              <p style={styles.muted}>{session?.name || "غير مسجل"}</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>حالتي</p>
              <p style={{ ...styles.statValue, color: driverOnline(currentDriver) ? "#86EFAC" : "#FCA5A5" }}>
                {driverOnline(currentDriver) ? "متصل" : "غير متصل"}
              </p>
              <p style={styles.muted}>{currentDriver ? getDriverPhone(currentDriver) || "بدون هاتف" : "غير محفوظ"}</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>قيد التوصيل</p>
              <p style={{ ...styles.statValue, color: "#7DD3FC" }}>{onDeliveryOrders.length}</p>
              <p style={styles.muted}>طلبات فعالة</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>أرباح اليوم</p>
              <p style={{ ...styles.statValue, color: "#FFB56B" }}>{earningsToday.toLocaleString()}</p>
              <p style={styles.muted}>تقديري 12%</p>
            </div>
          </div>
        </section>

        <section style={styles.panelGrid}>
          <aside style={styles.panel}>
            <h2 style={styles.sectionTitle}>حالة السائق</h2>

            <div style={styles.driverBox}>
              <p style={styles.statLabel}>الحساب</p>
              <h3 style={{ margin: "8px 0 0", fontSize: 24, fontWeight: 950 }}>
                {currentDriver ? getDriverName(currentDriver) : session?.name || "سائق"}
              </h3>
              <p style={{ ...styles.muted, direction: "ltr" }}>
                {currentDriver ? getDriverPhone(currentDriver) || session?.phone || "" : session?.phone || ""}
              </p>
              <span style={{ ...styles.badge, ...(driverOnline(currentDriver) ? styles.badgeGreen : styles.badgeRed) }}>
                {driverOnline(currentDriver) ? "متصل" : "غير متصل"}
              </span>
            </div>

            <button onClick={() => upsertDriverStatus(true)} disabled={saving} style={saving ? styles.disabledButton : styles.statusButton}>
              تشغيل واستلام طلبات
            </button>

            <button onClick={() => upsertDriverStatus(false)} disabled={saving} style={saving ? styles.disabledButton : styles.offlineButton}>
              إيقاف مؤقت
            </button>

            {message ? <div style={styles.messageOk}>{message}</div> : null}
            {error ? <div style={styles.messageBad}>{error}</div> : null}

            {role === "admin" ? (
              <div style={{ ...styles.driverBox, marginTop: 14 }}>
                <p style={styles.statLabel}>طلبات جاهزة بدون سائق</p>
                <p style={{ ...styles.statValue, color: "#FFB56B" }}>{readyOrders.length}</p>
                <p style={styles.muted}>تتوزع من صفحة التوزيع التلقائي.</p>
                <Link href="/auto-dispatch" style={{ ...styles.activePill, display: "inline-flex", marginTop: 10 }}>
                  فتح التوزيع
                </Link>
              </div>
            ) : null}
          </aside>

          <section style={styles.panel}>
            <h2 style={styles.sectionTitle}>طلباتي الحالية</h2>

            {myOrders.length === 0 ? (
              <div style={{ ...styles.empty, marginTop: 14 }}>
                <h3 style={{ margin: 0 }}>ماكو طلبات مرتبطة حالياً</h3>
                <p style={styles.muted}>إذا الإدارة وزعت طلب عليك، راح يظهر هنا مباشرة.</p>
              </div>
            ) : (
              <div style={styles.ordersGrid}>
                {myOrders.map((order) => {
                  const status = normalizeStatus(order.status);

                  return (
                    <article key={order.documentId} style={styles.orderCard}>
                      <div style={styles.orderTop}>
                        <div>
                          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                            <h3 style={{ margin: 0, fontSize: 23, fontWeight: 950 }}>{getCustomer(order)}</h3>
                            <span style={{ ...styles.badge, ...statusBadgeStyle(status) }}>{status}</span>
                          </div>
                          <p style={styles.muted}>{getRestaurant(order)} — {formatDate(order.createdAt)}</p>
                        </div>

                        <div style={styles.totalBox}>
                          <p style={styles.statLabel}>المجموع</p>
                          <p style={{ ...styles.statValue, ...styles.orange }}>{getTotal(order).toLocaleString()} د.ع</p>
                        </div>
                      </div>

                      <div style={styles.infoGrid}>
                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>الهاتف</p>
                          <p style={{ margin: "7px 0 0", direction: "ltr" }}>{getCustomerPhone(order) || "—"}</p>
                        </div>

                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>العنوان</p>
                          <p style={{ ...styles.muted, margin: "7px 0 0" }}>{order.address || "بدون عنوان"}</p>
                        </div>

                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>رقم الطلب</p>
                          <p style={{ margin: "7px 0 0", direction: "ltr" }}>{order.orderId || order.documentId.slice(0, 8)}</p>
                        </div>
                      </div>

                      <div style={styles.orderActions}>
                        <button
                          onClick={() => updateOrder(order, "قيد التوصيل")}
                          disabled={savingOrderId === order.documentId || status === "قيد التوصيل"}
                          style={savingOrderId === order.documentId || status === "قيد التوصيل" ? styles.disabledButton : styles.statusButton}
                        >
                          استلمت الطلب
                        </button>

                        <button
                          onClick={() => updateOrder(order, "تم التسليم")}
                          disabled={savingOrderId === order.documentId}
                          style={savingOrderId === order.documentId ? styles.disabledButton : styles.statusButton}
                        >
                          تم التسليم
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </section>
      </section>
    </main>
  );
}
