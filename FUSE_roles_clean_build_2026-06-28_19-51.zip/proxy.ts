﻿import { NextRequest, NextResponse } from "next/server";
import {
  FUSE_COOKIE_ROLE,
  canRoleAccessPath,
  fallbackPathForRole,
  isPublicPath,
  parseFuseRole,
} from "./lib/fuse-auth";

function isNextAsset(pathname: string) {
  return (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname === "/favicon.ico" ||
    pathname === "/manifest.json" ||
    pathname === "/robots.txt" ||
    pathname.includes(".")
  );
}

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (isNextAsset(pathname)) {
    return NextResponse.next();
  }

  const role = parseFuseRole(request.cookies.get(FUSE_COOKIE_ROLE)?.value);

  if (pathname === "/login") {
    if (role) {
      return NextResponse.redirect(new URL(fallbackPathForRole(role), request.url));
    }

    return NextResponse.next();
  }

  if (role && !canRoleAccessPath(role, pathname)) {
    return NextResponse.redirect(new URL(fallbackPathForRole(role), request.url));
  }

  if (!role && !isPublicPath(pathname)) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};

