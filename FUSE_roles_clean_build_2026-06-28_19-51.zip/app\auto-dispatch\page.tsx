﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebase";
import {
  FUSE_LOCAL_SESSION,
  parseFuseRole,
  roleHome,
  roleTitle,
  type FuseRole,
  type FuseSession,
} from "@/lib/fuse-auth";

type OrderDoc = {
  documentId: string;
  orderId?: string;
  customerName?: string;
  customer?: string;
  name?: string;
  phone?: string;
  customerPhone?: string;
  address?: string;
  restaurant?: string;
  restaurantName?: string;
  total?: number;
  amount?: number;
  status?: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  createdAt?: unknown;
};

type DriverDoc = {
  documentId: string;
  name?: string;
  driverName?: string;
  phone?: string;
  driverPhone?: string;
  status?: string;
  online?: boolean;
  isOnline?: boolean;
  rating?: number;
  currentOrders?: number;
  activeOrders?: number;
  distanceKm?: number;
  area?: string;
  lastSeen?: unknown;
};

function readSession(): FuseSession | null {
  try {
    const raw = localStorage.getItem(FUSE_LOCAL_SESSION);
    if (!raw) return null;

    const parsed = JSON.parse(raw) as FuseSession;
    const role = parseFuseRole(parsed.role);

    if (!parsed.email || !role) return null;

    return {
      ...parsed,
      role,
    };
  } catch {
    return null;
  }
}

function toDate(value: unknown): Date | null {
  if (!value) return null;

  try {
    if (
      typeof value === "object" &&
      value !== null &&
      "toDate" in value &&
      typeof (value as { toDate?: unknown }).toDate === "function"
    ) {
      return (value as { toDate: () => Date }).toDate();
    }

    if (value instanceof Date) return value;

    const date = new Date(value as string | number);
    return Number.isNaN(date.getTime()) ? null : date;
  } catch {
    return null;
  }
}

function formatDate(value: unknown) {
  const date = toDate(value);
  if (!date) return "بدون وقت";

  return date.toLocaleString("ar-IQ", {
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function normalizeStatus(status?: string) {
  if (!status) return "جديد";
  if (status === "جاهز") return "جاهز للتوصيل";
  if (status === "السائق استلم") return "قيد التوصيل";
  return status;
}

function getRestaurant(order: OrderDoc) {
  return order.restaurant || order.restaurantName || "مطعم";
}

function getCustomer(order: OrderDoc) {
  return order.customerName || order.customer || order.name || "زبون";
}

function getPhone(order: OrderDoc) {
  return order.phone || order.customerPhone || "";
}

function getTotal(order: OrderDoc) {
  return Number(order.total || order.amount || 0);
}

function getDriverName(driver: DriverDoc) {
  return driver.name || driver.driverName || "سائق";
}

function getDriverPhone(driver: DriverDoc) {
  return driver.phone || driver.driverPhone || "";
}

function isDriverOnline(driver: DriverDoc) {
  return driver.online === true || driver.isOnline === true || driver.status === "متصل";
}

function driverLoad(driver: DriverDoc) {
  return Number(driver.currentOrders || driver.activeOrders || 0);
}

function driverScore(driver: DriverDoc) {
  if (!isDriverOnline(driver)) return -999;

  const rating = Number(driver.rating || 4.5);
  const load = driverLoad(driver);
  const distance = Number(driver.distanceKm || 2);

  return Math.round(rating * 20 - load * 9 - distance * 4);
}

function orderCanDispatch(order: OrderDoc) {
  const status = normalizeStatus(order.status);

  return (
    !order.driverName &&
    !order.driverId &&
    (status === "جاهز للتوصيل" || status === "جاهز" || status === "جديد")
  );
}

function statusBadgeStyle(status?: string): CSSProperties {
  const clean = normalizeStatus(status);

  if (clean === "جديد") return styles.badgeOrange;
  if (clean === "قيد التحضير") return styles.badgeYellow;
  if (clean === "جاهز للتوصيل") return styles.badgeSky;
  if (clean === "قيد التوصيل") return styles.badgePurple;
  if (clean === "تم التسليم") return styles.badgeGreen;
  if (clean === "مرفوض") return styles.badgeRed;

  return styles.badgeMuted;
}

const styles: Record<string, CSSProperties> = {
  page: {
    minHeight: "100vh",
    background:
      "radial-gradient(circle at top right, rgba(255,122,0,0.16), transparent 34%), #050505",
    color: "white",
    padding: "26px 16px",
    fontFamily: "Arial, sans-serif",
  },
  shell: {
    width: "100%",
    maxWidth: 1200,
    margin: "0 auto",
  },
  topBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 16,
  },
  nav: {
    display: "flex",
    gap: 10,
    flexWrap: "wrap",
  },
  pill: {
    border: "1px solid rgba(255,255,255,0.13)",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    padding: "11px 16px",
    color: "rgba(255,255,255,0.82)",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 900,
  },
  activePill: {
    border: "1px solid rgba(255,122,0,0.35)",
    borderRadius: 999,
    background: "#FF7A00",
    padding: "11px 16px",
    color: "#000",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 950,
  },
  hero: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 34,
    background:
      "linear-gradient(135deg, rgba(255,255,255,0.075), rgba(255,122,0,0.10))",
    boxShadow: "0 24px 70px rgba(0,0,0,0.45)",
    padding: 22,
    marginBottom: 16,
  },
  heroGrid: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) repeat(4, minmax(150px, 0.32fr))",
    gap: 12,
    alignItems: "stretch",
  },
  card: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.36)",
    padding: 20,
  },
  compactCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 24,
    background: "rgba(0,0,0,0.34)",
    padding: 16,
    minHeight: 118,
  },
  eyebrow: {
    margin: 0,
    color: "#FF7A00",
    fontSize: 13,
    fontWeight: 950,
  },
  title: {
    margin: "8px 0 0",
    fontSize: "clamp(36px, 5vw, 60px)",
    lineHeight: 1.08,
    fontWeight: 950,
  },
  orange: {
    color: "#FF7A00",
  },
  muted: {
    color: "rgba(255,255,255,0.58)",
    lineHeight: 1.85,
    fontSize: 14,
  },
  statLabel: {
    margin: 0,
    color: "rgba(255,255,255,0.52)",
    fontSize: 13,
    fontWeight: 850,
  },
  statValue: {
    margin: "10px 0 0",
    fontSize: 30,
    fontWeight: 950,
  },
  layout: {
    display: "grid",
    gridTemplateColumns: "minmax(320px, 0.46fr) minmax(0, 1fr)",
    gap: 14,
    marginBottom: 16,
  },
  panel: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 30,
    background: "rgba(255,255,255,0.045)",
    padding: 18,
  },
  sectionTitle: {
    margin: 0,
    fontSize: 24,
    fontWeight: 950,
  },
  select: {
    width: "100%",
    boxSizing: "border-box",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 18,
    background: "#070707",
    color: "white",
    padding: "15px 16px",
    outline: "none",
    fontSize: 15,
    marginTop: 14,
  },
  orderSummary: {
    border: "1px solid rgba(255,122,0,0.22)",
    borderRadius: 24,
    background: "rgba(255,122,0,0.08)",
    padding: 16,
    marginTop: 14,
  },
  mainButton: {
    width: "100%",
    border: 0,
    borderRadius: 18,
    background: "#FF7A00",
    color: "#000",
    padding: "15px 16px",
    cursor: "pointer",
    fontSize: 14,
    fontWeight: 950,
    marginTop: 14,
  },
  disabledButton: {
    width: "100%",
    border: 0,
    borderRadius: 18,
    background: "rgba(255,255,255,0.09)",
    color: "rgba(255,255,255,0.35)",
    padding: "15px 16px",
    fontSize: 14,
    fontWeight: 950,
    marginTop: 14,
  },
  driversGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: 12,
    marginTop: 14,
  },
  driverCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 24,
    background: "rgba(0,0,0,0.30)",
    padding: 16,
  },
  driverTop: {
    display: "flex",
    justifyContent: "space-between",
    gap: 10,
    alignItems: "flex-start",
  },
  driverStats: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 8,
    marginTop: 14,
  },
  miniBox: {
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 16,
    background: "rgba(255,255,255,0.04)",
    padding: 10,
  },
  badge: {
    display: "inline-flex",
    alignItems: "center",
    border: "1px solid",
    borderRadius: 999,
    padding: "7px 11px",
    fontSize: 12,
    fontWeight: 950,
  },
  badgeOrange: {
    borderColor: "rgba(255,122,0,0.42)",
    background: "rgba(255,122,0,0.12)",
    color: "#FFB56B",
  },
  badgeYellow: {
    borderColor: "rgba(234,179,8,0.42)",
    background: "rgba(234,179,8,0.12)",
    color: "#FDE68A",
  },
  badgeSky: {
    borderColor: "rgba(14,165,233,0.42)",
    background: "rgba(14,165,233,0.12)",
    color: "#7DD3FC",
  },
  badgePurple: {
    borderColor: "rgba(168,85,247,0.42)",
    background: "rgba(168,85,247,0.12)",
    color: "#D8B4FE",
  },
  badgeGreen: {
    borderColor: "rgba(34,197,94,0.42)",
    background: "rgba(34,197,94,0.12)",
    color: "#86EFAC",
  },
  badgeRed: {
    borderColor: "rgba(239,68,68,0.42)",
    background: "rgba(239,68,68,0.12)",
    color: "#FCA5A5",
  },
  badgeMuted: {
    borderColor: "rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    color: "rgba(255,255,255,0.65)",
  },
  messageOk: {
    border: "1px solid rgba(34,197,94,0.30)",
    borderRadius: 18,
    background: "rgba(34,197,94,0.10)",
    color: "#86EFAC",
    padding: 14,
    marginTop: 14,
    fontSize: 14,
    fontWeight: 900,
  },
  messageBad: {
    border: "1px solid rgba(239,68,68,0.30)",
    borderRadius: 18,
    background: "rgba(239,68,68,0.10)",
    color: "#FCA5A5",
    padding: 14,
    marginTop: 14,
    fontSize: 14,
    fontWeight: 900,
  },
  empty: {
    border: "1px dashed rgba(255,255,255,0.16)",
    borderRadius: 24,
    background: "rgba(255,255,255,0.035)",
    padding: 24,
    textAlign: "center",
  },
};

export default function AutoDispatchPage() {
  const [session, setSession] = useState<FuseSession | null>(null);
  const [orders, setOrders] = useState<OrderDoc[]>([]);
  const [drivers, setDrivers] = useState<DriverDoc[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState("");
  const [selectedDriverId, setSelectedDriverId] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const saved = readSession();

    if (!saved) {
      window.location.href = "/login?next=/auto-dispatch";
      return;
    }

    if (saved.role !== "admin") {
      window.location.href = roleHome[saved.role] || "/live-orders";
      return;
    }

    setSession(saved);
  }, []);

  useEffect(() => {
    const q = query(collection(db, "orders"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((item) => ({
          ...(item.data() as Omit<OrderDoc, "documentId">),
          documentId: item.id,
        }));

        setOrders(data);
      },
      (snapshotError) => setError(snapshotError.message || "تعذر تحميل الطلبات")
    );

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, "drivers"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((item) => ({
          ...(item.data() as Omit<DriverDoc, "documentId">),
          documentId: item.id,
        }));

        setDrivers(data);
      },
      () => setDrivers([])
    );

    return () => unsubscribe();
  }, []);

  const readyOrders = useMemo(() => {
    return orders
      .filter(orderCanDispatch)
      .sort((a, b) => {
        const aDate = toDate(a.createdAt)?.getTime() || 0;
        const bDate = toDate(b.createdAt)?.getTime() || 0;
        return bDate - aDate;
      });
  }, [orders]);

  const onlineDrivers = useMemo(() => {
    return drivers
      .filter(isDriverOnline)
      .sort((a, b) => driverScore(b) - driverScore(a));
  }, [drivers]);

  const selectedOrder = useMemo(() => {
    return readyOrders.find((order) => order.documentId === selectedOrderId) || readyOrders[0] || null;
  }, [readyOrders, selectedOrderId]);

  const recommendedDriver = onlineDrivers[0] || null;

  const selectedDriver = useMemo(() => {
    return (
      onlineDrivers.find((driver) => driver.documentId === selectedDriverId) ||
      recommendedDriver ||
      null
    );
  }, [onlineDrivers, recommendedDriver, selectedDriverId]);

  const activeOrders = orders.filter((order) => {
    const status = normalizeStatus(order.status);
    return status !== "تم التسليم" && status !== "مرفوض";
  }).length;

  const alreadyAssigned = orders.filter((order) => order.driverId || order.driverName).length;
  const readyCount = readyOrders.length;

  async function assignDriver(driver?: DriverDoc | null) {
    setMessage("");
    setError("");

    const order = selectedOrder;
    const targetDriver = driver || selectedDriver;

    if (!order) {
      setError("ماكو طلب جاهز للتوزيع.");
      return;
    }

    if (!targetDriver) {
      setError("ماكو سائق متصل حالياً.");
      return;
    }

    setSaving(true);

    try {
      await updateDoc(doc(db, "orders", order.documentId), {
        driverId: targetDriver.documentId,
        driverName: getDriverName(targetDriver),
        driverPhone: getDriverPhone(targetDriver),
        status: "قيد التوصيل",
        dispatchedAt: serverTimestamp(),
        dispatchMode: "auto",
      });

      setMessage(`تم ربط الطلب مع السائق ${getDriverName(targetDriver)}.`);
      setSelectedOrderId("");
      setSelectedDriverId("");
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "تعذر ربط السائق بالطلب");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main dir="rtl" style={styles.page}>
      <section style={styles.shell}>
        <header style={styles.topBar}>
          <nav style={styles.nav}>
            <Link href="/" style={styles.pill}>
              الرئيسية
            </Link>
            <Link href="/driver-app" style={styles.pill}>
              السائق
            </Link>
            <Link href="/drivers-admin" style={styles.pill}>
              إدارة السائقين
            </Link>
            <Link href="/fuse-admin" style={styles.pill}>
              لوحة الإدارة
            </Link>
            <Link href="/auto-dispatch" style={styles.activePill}>
              التوزيع
            </Link>
          </nav>

          <Link href={roleHome.admin} style={styles.pill}>
            لوحتي
          </Link>
        </header>

        <section style={styles.hero}>
          <div style={styles.heroGrid}>
            <div style={styles.card}>
              <p style={styles.eyebrow}>التوزيع التلقائي</p>
              <h1 style={styles.title}>
                فيوز يختار
                <br />
                <span style={styles.orange}>أفضل سائق</span>
              </h1>
              <p style={styles.muted}>
                النظام يحسب أفضل سائق حسب الاتصال، عدد الطلبات الحالية، التقييم، والمسافة التقريبية.
              </p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>الدور</p>
              <p style={{ ...styles.statValue, ...styles.orange }}>
                {session ? roleTitle[session.role] : "—"}
              </p>
              <p style={styles.muted}>{session?.name || "غير مسجل"}</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>طلبات جاهزة</p>
              <p style={{ ...styles.statValue, color: "#FFB56B" }}>{readyCount}</p>
              <p style={styles.muted}>تحتاج سائق</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>سائقين متصلين</p>
              <p style={{ ...styles.statValue, color: "#86EFAC" }}>{onlineDrivers.length}</p>
              <p style={styles.muted}>جاهزين للتوزيع</p>
            </div>

            <div style={styles.compactCard}>
              <p style={styles.statLabel}>طلبات نشطة</p>
              <p style={{ ...styles.statValue, color: "#7DD3FC" }}>{activeOrders}</p>
              <p style={styles.muted}>مربوطة: {alreadyAssigned}</p>
            </div>
          </div>
        </section>

        <section style={styles.layout}>
          <aside style={styles.panel}>
            <h2 style={styles.sectionTitle}>الطلب المراد توزيعه</h2>

            <select
              value={selectedOrder?.documentId || ""}
              onChange={(event) => setSelectedOrderId(event.target.value)}
              style={styles.select}
            >
              {readyOrders.length === 0 ? (
                <option value="">لا توجد طلبات جاهزة</option>
              ) : (
                readyOrders.map((order) => (
                  <option key={order.documentId} value={order.documentId}>
                    {getCustomer(order)} — {getRestaurant(order)} — {getTotal(order).toLocaleString()} د.ع
                  </option>
                ))
              )}
            </select>

            {selectedOrder ? (
              <div style={styles.orderSummary}>
                <p style={styles.statLabel}>الطلب المختار</p>
                <h3 style={{ margin: "8px 0 0", fontSize: 23, fontWeight: 950 }}>
                  {getCustomer(selectedOrder)}
                </h3>
                <p style={styles.muted}>
                  {getRestaurant(selectedOrder)} — {formatDate(selectedOrder.createdAt)}
                </p>
                <p style={{ ...styles.muted, direction: "ltr" }}>
                  {getPhone(selectedOrder) || "بدون هاتف"}
                </p>
                <span style={{ ...styles.badge, ...statusBadgeStyle(selectedOrder.status) }}>
                  {normalizeStatus(selectedOrder.status)}
                </span>
              </div>
            ) : (
              <div style={{ ...styles.empty, marginTop: 14 }}>
                <h3 style={{ margin: 0 }}>ماكو طلب جاهز للتوزيع</h3>
                <p style={styles.muted}>
                  حوّل طلب من لوحة المطعم إلى جاهز للتوصيل.
                </p>
              </div>
            )}

            <button
              onClick={() => assignDriver(recommendedDriver)}
              disabled={!selectedOrder || !recommendedDriver || saving}
              style={!selectedOrder || !recommendedDriver || saving ? styles.disabledButton : styles.mainButton}
            >
              {saving ? "جاري التوزيع..." : "توزيع تلقائي على الأفضل"}
            </button>

            {message ? <div style={styles.messageOk}>{message}</div> : null}
            {error ? <div style={styles.messageBad}>{error}</div> : null}
          </aside>

          <section style={styles.panel}>
            <h2 style={styles.sectionTitle}>السائقين المتصلين</h2>

            {onlineDrivers.length === 0 ? (
              <div style={{ ...styles.empty, marginTop: 14 }}>
                <h3 style={{ margin: 0 }}>ماكو سائق متصل</h3>
                <p style={styles.muted}>افتح تطبيق السائق وخلي الحالة متصل.</p>
              </div>
            ) : (
              <div style={styles.driversGrid}>
                {onlineDrivers.map((driver, index) => {
                  const isRecommended = driver.documentId === recommendedDriver?.documentId;
                  const isSelected = driver.documentId === selectedDriver?.documentId;

                  return (
                    <article
                      key={driver.documentId}
                      style={{
                        ...styles.driverCard,
                        borderColor: isSelected
                          ? "rgba(255,122,0,0.55)"
                          : "rgba(255,255,255,0.10)",
                      }}
                    >
                      <div style={styles.driverTop}>
                        <div>
                          <h3 style={{ margin: 0, fontSize: 21, fontWeight: 950 }}>
                            {getDriverName(driver)}
                          </h3>
                          <p style={{ ...styles.muted, margin: "7px 0 0", direction: "ltr" }}>
                            {getDriverPhone(driver) || "بدون هاتف"}
                          </p>
                        </div>

                        <div style={{ display: "grid", gap: 7, justifyItems: "end" }}>
                          <span style={{ ...styles.badge, ...styles.badgeGreen }}>
                            متصل
                          </span>

                          {isRecommended ? (
                            <span style={{ ...styles.badge, ...styles.badgeOrange }}>
                              الأفضل
                            </span>
                          ) : null}
                        </div>
                      </div>

                      <div style={styles.driverStats}>
                        <div style={styles.miniBox}>
                          <p style={styles.statLabel}>Score</p>
                          <p style={{ margin: "7px 0 0", fontWeight: 950 }}>
                            {driverScore(driver)}
                          </p>
                        </div>

                        <div style={styles.miniBox}>
                          <p style={styles.statLabel}>طلبات</p>
                          <p style={{ margin: "7px 0 0", fontWeight: 950 }}>
                            {driverLoad(driver)}
                          </p>
                        </div>

                        <div style={styles.miniBox}>
                          <p style={styles.statLabel}>تقييم</p>
                          <p style={{ margin: "7px 0 0", fontWeight: 950 }}>
                            {Number(driver.rating || 4.5).toFixed(1)}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedDriverId(driver.documentId);
                          assignDriver(driver);
                        }}
                        disabled={!selectedOrder || saving}
                        style={!selectedOrder || saving ? styles.disabledButton : styles.mainButton}
                      >
                        ربط هذا السائق
                      </button>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </section>
      </section>
    </main>
  );
}
