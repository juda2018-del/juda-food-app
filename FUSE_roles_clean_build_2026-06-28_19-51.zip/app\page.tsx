﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { useRouter } from "next/navigation";
import {
  FUSE_COOKIE_EMAIL,
  FUSE_COOKIE_NAME,
  FUSE_COOKIE_PHONE,
  FUSE_COOKIE_RESTAURANT,
  FUSE_COOKIE_ROLE,
  FUSE_LOCAL_SESSION,
  navForRole,
  parseFuseRole,
  roleHome,
  roleTitle,
  type FuseRole,
  type FuseSession,
} from "@/lib/fuse-auth";

type Restaurant = {
  name: string;
  desc: string;
  href: string;
  image: string;
  tag: string;
  lat: number;
  lng: number;
};

type RestaurantWithDistance = Restaurant & {
  distance: number | null;
  isAvailable: boolean;
};

const DELIVERY_RADIUS_KM = 7;

const المطاعم: Restaurant[] = [
  {
    name: "فيروز",
    desc: "كاهي، قيمر، بورك وفطور عراقي",
    href: "/fayrouz",
    image: "/images/fayrouz.jpg",
    tag: "فطور عراقي",
    lat: 33.2965,
    lng: 44.4445,
  },
  {
    name: "شلتتة",
    desc: "مشلتت وفطير مصري حار وحلو",
    href: "/ahram",
    image: "/images/ahram.jpg",
    tag: "مشلتت وفطير",
    lat: 33.2968,
    lng: 44.445,
  },
  {
    name: "خان قدوري",
    desc: "أكلات عراقية بطعم أصيل",
    href: "/khan",
    image: "/images/khan.jpg",
    tag: "أكل عراقي",
    lat: 33.3152,
    lng: 44.3661,
  },
];

function clearCookie(name: string) {
  document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax`;
}

function readSession(): FuseSession | null {
  try {
    const raw = localStorage.getItem(FUSE_LOCAL_SESSION);
    if (!raw) return null;

    const parsed = JSON.parse(raw) as FuseSession;
    const role = parseFuseRole(parsed.role);

    if (!parsed.email || !role) return null;

    return {
      ...parsed,
      role,
    };
  } catch {
    return null;
  }
}

function getDistanceKm(
  userLat: number,
  userLng: number,
  restaurantLat: number,
  restaurantLng: number
) {
  const radius = 6371;
  const dLat = ((restaurantLat - userLat) * Math.PI) / 180;
  const dLng = ((restaurantLng - userLng) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((userLat * Math.PI) / 180) *
      Math.cos((restaurantLat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return radius * c;
}

const roleColors: Record<FuseRole, CSSProperties> = {
  admin: {
    borderColor: "rgba(255,122,0,0.44)",
    background: "rgba(255,122,0,0.12)",
    color: "#FFB56B",
  },
  restaurant: {
    borderColor: "rgba(34,197,94,0.44)",
    background: "rgba(34,197,94,0.12)",
    color: "#86EFAC",
  },
  driver: {
    borderColor: "rgba(14,165,233,0.44)",
    background: "rgba(14,165,233,0.12)",
    color: "#7DD3FC",
  },
  customer: {
    borderColor: "rgba(168,85,247,0.44)",
    background: "rgba(168,85,247,0.12)",
    color: "#D8B4FE",
  },
};

const styles: Record<string, CSSProperties> = {
  page: {
    minHeight: "100vh",
    background:
      "radial-gradient(circle at top right, rgba(255,122,0,0.17), transparent 34%), #050505",
    color: "white",
    padding: "26px 16px",
    fontFamily: "Arial, sans-serif",
  },
  shell: {
    width: "100%",
    maxWidth: 1180,
    margin: "0 auto",
  },
  topBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 16,
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 12,
  },
  logo: {
    width: 54,
    height: 54,
    borderRadius: 18,
    background:
      "linear-gradient(135deg, rgba(255,122,0,1), rgba(255,181,107,0.9))",
    color: "#000",
    display: "grid",
    placeItems: "center",
    fontSize: 18,
    fontWeight: 950,
    boxShadow: "0 18px 45px rgba(255,122,0,0.20)",
  },
  brandTitle: {
    margin: 0,
    fontSize: 23,
    fontWeight: 950,
  },
  brandSub: {
    margin: "4px 0 0",
    color: "rgba(255,255,255,0.48)",
    fontSize: 12,
    fontWeight: 800,
  },
  actionRow: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    flexWrap: "wrap",
  },
  pill: {
    border: "1px solid rgba(255,255,255,0.13)",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    padding: "11px 16px",
    color: "rgba(255,255,255,0.82)",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 900,
  },
  primaryButton: {
    border: 0,
    borderRadius: 999,
    background: "#FF7A00",
    color: "#000",
    padding: "12px 17px",
    cursor: "pointer",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 950,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
  },
  logoutButton: {
    border: "1px solid rgba(239,68,68,0.32)",
    borderRadius: 999,
    background: "rgba(239,68,68,0.10)",
    color: "#FECACA",
    padding: "12px 17px",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 950,
  },
  hero: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 34,
    background:
      "linear-gradient(135deg, rgba(255,255,255,0.075), rgba(255,122,0,0.10))",
    boxShadow: "0 24px 70px rgba(0,0,0,0.48)",
    padding: 22,
    marginBottom: 16,
  },
  heroGrid: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1.35fr) minmax(280px, 0.65fr)",
    gap: 14,
    alignItems: "stretch",
  },
  heroCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.38)",
    padding: 22,
  },
  eyebrow: {
    margin: 0,
    color: "#FF7A00",
    fontSize: 13,
    fontWeight: 950,
  },
  title: {
    margin: "8px 0 0",
    fontSize: "clamp(38px, 6vw, 68px)",
    lineHeight: 1.08,
    fontWeight: 950,
  },
  orange: {
    color: "#FF7A00",
  },
  text: {
    color: "rgba(255,255,255,0.60)",
    lineHeight: 1.9,
    fontSize: 14,
  },
  sessionCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.34)",
    padding: 20,
  },
  badge: {
    display: "inline-flex",
    border: "1px solid",
    borderRadius: 999,
    padding: "7px 11px",
    fontSize: 12,
    fontWeight: 950,
  },
  statsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
    gap: 12,
    marginTop: 14,
  },
  stat: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 22,
    background: "rgba(0,0,0,0.30)",
    padding: 16,
  },
  statLabel: {
    margin: 0,
    color: "rgba(255,255,255,0.52)",
    fontSize: 12,
    fontWeight: 850,
  },
  statValue: {
    margin: "8px 0 0",
    fontSize: 26,
    fontWeight: 950,
  },
  section: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 30,
    background: "rgba(255,255,255,0.045)",
    padding: 18,
    marginBottom: 16,
  },
  sectionHead: {
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 14,
  },
  sectionTitle: {
    margin: 0,
    fontSize: 28,
    fontWeight: 950,
  },
  roleMenu: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
    gap: 12,
  },
  menuItem: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 24,
    background: "rgba(0,0,0,0.32)",
    padding: 16,
    color: "white",
    textDecoration: "none",
    minHeight: 96,
  },
  menuTitle: {
    margin: 0,
    fontSize: 17,
    fontWeight: 950,
  },
  menuDesc: {
    margin: "8px 0 0",
    color: "rgba(255,255,255,0.48)",
    fontSize: 13,
    lineHeight: 1.7,
  },
  المطاعمGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: 13,
  },
  restaurantCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 26,
    background: "rgba(0,0,0,0.32)",
    overflow: "hidden",
  },
  restaurantImage: {
    height: 150,
    background:
      "linear-gradient(135deg, rgba(255,122,0,0.35), rgba(255,255,255,0.06))",
    display: "grid",
    placeItems: "center",
    fontSize: 42,
    fontWeight: 950,
    color: "rgba(255,255,255,0.90)",
  },
  restaurantBody: {
    padding: 16,
  },
  smallTag: {
    display: "inline-flex",
    borderRadius: 999,
    padding: "7px 10px",
    background: "rgba(255,122,0,0.12)",
    color: "#FFB56B",
    fontSize: 12,
    fontWeight: 950,
  },
  restaurantName: {
    margin: "12px 0 0",
    fontSize: 22,
    fontWeight: 950,
  },
  restaurantButton: {
    marginTop: 14,
    display: "block",
    borderRadius: 17,
    background: "#FF7A00",
    color: "#000",
    padding: "13px 14px",
    textDecoration: "none",
    textAlign: "center",
    fontSize: 13,
    fontWeight: 950,
  },
  disabledButton: {
    marginTop: 14,
    display: "block",
    borderRadius: 17,
    background: "rgba(255,255,255,0.08)",
    color: "rgba(255,255,255,0.36)",
    padding: "13px 14px",
    textDecoration: "none",
    textAlign: "center",
    fontSize: 13,
    fontWeight: 950,
  },
  notice: {
    border: "1px solid rgba(255,122,0,0.20)",
    borderRadius: 24,
    background: "rgba(255,122,0,0.08)",
    padding: 16,
  },
};

export default function HomePage() {
  const router = useRouter();

  const [session, setSession] = useState<FuseSession | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState("تفعيل الموقع يعرض المطاعم الأقرب لك");

  useEffect(() => {
    setSession(readSession());

    if (!navigator.geolocation) {
      setLocationStatus("جهازك لا يدعم تحديد الموقع");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLocationStatus("تم تحديد موقعك");
      },
      () => {
        setLocationStatus("فعّل الموقع حتى نرتب المطاعم حسب القرب");
      },
      {
        enableHighAccuracy: true,
        timeout: 9000,
        maximumAge: 0,
      }
    );
  }, []);

  const role: FuseRole | null = session?.role || null;

  const navItems = useMemo(() => {
    return navForRole(role);
  }, [role]);

  const المطاعمWithDistance: RestaurantWithDistance[] = useMemo(() => {
    if (!userLocation) {
      return المطاعم.map((restaurant) => ({
        ...restaurant,
        distance: null,
        isAvailable: true,
      }));
    }

    return المطاعم
      .map((restaurant) => {
        const distance = getDistanceKm(
          userLocation.lat,
          userLocation.lng,
          restaurant.lat,
          restaurant.lng
        );

        return {
          ...restaurant,
          distance,
          isAvailable: distance <= DELIVERY_RADIUS_KM,
        };
      })
      .sort((a, b) => (a.distance || 999) - (b.distance || 999));
  }, [userLocation]);

  function logout() {
    localStorage.removeItem(FUSE_LOCAL_SESSION);

    clearCookie(FUSE_COOKIE_ROLE);
    clearCookie(FUSE_COOKIE_EMAIL);
    clearCookie(FUSE_COOKIE_NAME);
    clearCookie(FUSE_COOKIE_PHONE);
    clearCookie(FUSE_COOKIE_RESTAURANT);

    setSession(null);
    router.replace("/login");
    router.refresh();
  }

  return (
    <main dir="rtl" style={styles.page}>
      <section style={styles.shell}>
        <div style={styles.topBar}>
          <div style={styles.brand}>
            <div style={styles.logo}>F</div>
            <div>
              <h1 style={styles.brandTitle}>FUSE Iraq</h1>
              <p style={styles.brandSub}>نظام توصيل وتشغيل المطاعم</p>
            </div>
          </div>

          <div style={styles.actionRow}>
            {session ? (
              <>
                <Link href={role ? roleHome[role] : "/live-orders"} style={styles.primaryButton}>
                  لوحتي
                </Link>
                <button onClick={logout} style={styles.logoutButton}>
                  خروج
                </button>
              </>
            ) : (
              <Link href="/login" style={styles.primaryButton}>
                تسجيل دخول
              </Link>
            )}
          </div>
        </div>

        <header style={styles.hero}>
          <div style={styles.heroGrid}>
            <div style={styles.heroCard}>
              <p style={styles.eyebrow}>فيوز مباشر</p>
              <h2 style={styles.title}>
                طلبات أسرع
                <br />
                <span style={styles.orange}>وتحكم أوضح</span>
              </h2>
              <p style={styles.text}>
                اختار مطعمك، تابع طلبك مباشرة، وشوف التحديثات لحظة بلحظة من الاستلام إلى التوصيل.
              </p>

              <div style={styles.statsGrid}>
                <div style={styles.stat}>
                  <p style={styles.statLabel}>نطاق التوصيل</p>
                  <p style={styles.statValue}>7 كم</p>
                </div>
                <div style={styles.stat}>
                  <p style={styles.statLabel}>الحالة</p>
                  <p style={{ ...styles.statValue, color: "#86EFAC" }}>مباشر</p>
                </div>
                <div style={styles.stat}>
                  <p style={styles.statLabel}>القوائم</p>
                  <p style={{ ...styles.statValue, color: "#FFB56B" }}>حسب دورك</p>
                </div>
              </div>
            </div>

            <aside style={styles.sessionCard}>
              <p style={styles.eyebrow}>حسابك</p>

              {session && role ? (
                <>
                  <h3 style={{ margin: "12px 0 0", fontSize: 28, fontWeight: 950 }}>
                    {session.name}
                  </h3>
                  <p style={{ ...styles.text, margin: "7px 0 0", direction: "ltr" }}>
                    {session.email}
                  </p>
                  <div style={{ marginTop: 14 }}>
                    <span style={{ ...styles.badge, ...roleColors[role] }}>
                      {roleTitle[role]}
                    </span>
                  </div>
                  <Link
                    href={roleHome[role]}
                    style={{ ...styles.primaryButton, marginTop: 18, width: "100%" }}
                  >
                    دخول لوحتي
                  </Link>
                </>
              ) : (
                <>
                  <h3 style={{ margin: "12px 0 0", fontSize: 28, fontWeight: 950 }}>
                    زائر
                  </h3>
                  <p style={styles.text}>
                    سجل دخول حتى تظهر لك القائمة المناسبة لدورك.
                  </p>
                  <Link
                    href="/login"
                    style={{ ...styles.primaryButton, marginTop: 18, width: "100%" }}
                  >
                    دخول
                  </Link>
                </>
              )}

              <div style={{ ...styles.notice, marginTop: 16 }}>
                <p style={{ margin: 0, color: "#FFB56B", fontWeight: 950 }}>
                  تتبع طلبك بسهولة
                </p>
                <p style={{ ...styles.text, margin: "8px 0 0" }}>
                  تابع حالة طلبك مباشرة من لحظة الاستلام إلى التوصيل.
                </p>
              </div>
            </aside>
          </div>
        </header>

        <section style={styles.section}>
          <div style={styles.sectionHead}>
            <div>
              <p style={styles.eyebrow}>القائمة</p>
              <h2 style={styles.sectionTitle}>قائمتي</h2>
            </div>
            <span style={styles.pill}>{role ? roleTitle[role] : "زائر"}</span>
          </div>

          <div style={styles.roleMenu}>
            {navItems.map((item) => (
              <Link key={`${item.title}-${item.href}`} href={item.href} style={styles.menuItem}>
                <h3 style={styles.menuTitle}>{item.title}</h3>
                <p style={styles.menuDesc}>{item.desc}</p>
              </Link>
            ))}
          </div>
        </section>

        <section style={styles.section}>
          <div style={styles.sectionHead}>
            <div>
              <p style={styles.eyebrow}>المطاعم</p>
              <h2 style={styles.sectionTitle}>المطاعم القريبة</h2>
            </div>
            <span style={styles.pill}>{locationStatus}</span>
          </div>

          <div style={styles.المطاعمGrid}>
            {المطاعمWithDistance.map((restaurant) => (
              <article key={restaurant.name} style={styles.restaurantCard}>
                <div style={styles.restaurantImage}>
                  {restaurant.name.slice(0, 1)}
                </div>

                <div style={styles.restaurantBody}>
                  <span style={styles.smallTag}>{restaurant.tag}</span>

                  <h3 style={styles.restaurantName}>{restaurant.name}</h3>
                  <p style={styles.text}>{restaurant.desc}</p>

                  <p style={{ ...styles.text, margin: "8px 0 0" }}>
                    {restaurant.distance === null
                      ? "المسافة تظهر بعد تفعيل الموقع"
                      : `${restaurant.distance.toFixed(1)} كم عنك`}
                  </p>

                  <Link
                    href={restaurant.isAvailable ? restaurant.href : "#"}
                    style={restaurant.isAvailable ? styles.restaurantButton : styles.disabledButton}
                  >
                    {restaurant.isAvailable ? "اطلب الآن" : "خارج النطاق"}
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </section>
      </section>
    </main>
  );
}




