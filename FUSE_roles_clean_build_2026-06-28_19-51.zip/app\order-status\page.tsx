﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "../firebase";

type OrderItem = {
  name?: string;
  title?: string;
  price?: number;
  qty?: number;
  quantity?: number;
};

type OrderDoc = {
  documentId: string;
  orderId?: string;
  customerName?: string;
  customer?: string;
  name?: string;
  phone?: string;
  customerPhone?: string;
  address?: string;
  restaurant?: string;
  restaurantName?: string;
  total?: number;
  amount?: number;
  status?: string;
  driverName?: string;
  driverPhone?: string;
  createdAt?: unknown;
  items?: OrderItem[];
};

const steps = ["جديد", "قيد التحضير", "جاهز للتوصيل", "قيد التوصيل", "تم التسليم"];

function cleanPhone(value?: string) {
  return (value || "").replace(/\D/g, "");
}

function normalizeStatus(status?: string) {
  if (!status) return "جديد";
  if (status === "جاهز") return "جاهز للتوصيل";
  if (status === "السائق استلم") return "قيد التوصيل";
  return status;
}

function getPhone(order: OrderDoc) {
  return order.phone || order.customerPhone || "";
}

function getCustomer(order: OrderDoc) {
  return order.customerName || order.customer || order.name || "زبون";
}

function getRestaurant(order: OrderDoc) {
  return order.restaurant || order.restaurantName || "مطعم";
}

function getTotal(order: OrderDoc) {
  return Number(order.total || order.amount || 0);
}

function formatDate(value: unknown) {
  if (!value) return "بدون وقت";

  try {
    let date: Date;

    if (
      typeof value === "object" &&
      value !== null &&
      "toDate" in value &&
      typeof (value as { toDate?: unknown }).toDate === "function"
    ) {
      date = (value as { toDate: () => Date }).toDate();
    } else if (value instanceof Date) {
      date = value;
    } else {
      date = new Date(value as string | number);
    }

    if (Number.isNaN(date.getTime())) return "بدون وقت";

    return date.toLocaleString("ar-IQ", {
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  } catch {
    return "بدون وقت";
  }
}

function matchesSearch(order: OrderDoc, search: string) {
  const value = search.trim().toLowerCase();
  const phoneValue = cleanPhone(search);

  if (!value && !phoneValue) return false;

  const orderPhone = cleanPhone(getPhone(order));
  const orderId = (order.orderId || order.documentId || "").toLowerCase();

  if (phoneValue.length >= 5 && orderPhone) {
    return orderPhone.includes(phoneValue) || phoneValue.includes(orderPhone);
  }

  return orderId.includes(value);
}

function badgeStyle(status?: string): CSSProperties {
  const clean = normalizeStatus(status);

  if (clean === "جديد") return styles.badgeOrange;
  if (clean === "قيد التحضير") return styles.badgeYellow;
  if (clean === "جاهز للتوصيل") return styles.badgeSky;
  if (clean === "قيد التوصيل") return styles.badgePurple;
  if (clean === "تم التسليم") return styles.badgeGreen;
  if (clean === "مرفوض") return styles.badgeRed;

  return styles.badgeMuted;
}

const styles: Record<string, CSSProperties> = {
  page: {
    minHeight: "100vh",
    background:
      "radial-gradient(circle at top right, rgba(255,122,0,0.16), transparent 34%), #050505",
    color: "white",
    padding: "26px 16px",
    fontFamily: "Arial, sans-serif",
  },
  shell: {
    width: "100%",
    maxWidth: 1100,
    margin: "0 auto",
  },
  topBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 16,
  },
  pill: {
    border: "1px solid rgba(255,255,255,0.13)",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    padding: "11px 16px",
    color: "rgba(255,255,255,0.82)",
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 900,
  },
  hero: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 34,
    background:
      "linear-gradient(135deg, rgba(255,255,255,0.075), rgba(255,122,0,0.10))",
    boxShadow: "0 24px 70px rgba(0,0,0,0.45)",
    padding: 22,
    marginBottom: 16,
  },
  heroGrid: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) minmax(260px, 0.45fr)",
    gap: 14,
    alignItems: "stretch",
  },
  card: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(0,0,0,0.36)",
    padding: 20,
  },
  eyebrow: {
    margin: 0,
    color: "#FF7A00",
    fontSize: 13,
    fontWeight: 950,
  },
  title: {
    margin: "8px 0 0",
    fontSize: "clamp(38px, 6vw, 66px)",
    lineHeight: 1.08,
    fontWeight: 950,
  },
  orange: {
    color: "#FF7A00",
  },
  muted: {
    color: "rgba(255,255,255,0.58)",
    lineHeight: 1.85,
    fontSize: 14,
  },
  searchBox: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 28,
    background: "rgba(255,255,255,0.045)",
    padding: 18,
    marginBottom: 16,
  },
  input: {
    width: "100%",
    boxSizing: "border-box",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 18,
    background: "#070707",
    color: "white",
    padding: "15px 16px",
    outline: "none",
    fontSize: 15,
  },
  resultGrid: {
    display: "grid",
    gap: 14,
  },
  orderCard: {
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 30,
    background: "rgba(255,255,255,0.045)",
    padding: 18,
  },
  orderTop: {
    display: "grid",
    gridTemplateColumns: "minmax(260px, 1fr) minmax(200px, 0.45fr)",
    gap: 12,
    alignItems: "start",
  },
  totalBox: {
    border: "1px solid rgba(255,122,0,0.24)",
    borderRadius: 22,
    background: "rgba(255,122,0,0.10)",
    padding: 16,
  },
  statLabel: {
    margin: 0,
    color: "rgba(255,255,255,0.52)",
    fontSize: 13,
    fontWeight: 850,
  },
  statValue: {
    margin: "10px 0 0",
    fontSize: 30,
    fontWeight: 950,
  },
  badge: {
    display: "inline-flex",
    alignItems: "center",
    border: "1px solid",
    borderRadius: 999,
    padding: "7px 11px",
    fontSize: 12,
    fontWeight: 950,
  },
  badgeOrange: {
    borderColor: "rgba(255,122,0,0.42)",
    background: "rgba(255,122,0,0.12)",
    color: "#FFB56B",
  },
  badgeYellow: {
    borderColor: "rgba(234,179,8,0.42)",
    background: "rgba(234,179,8,0.12)",
    color: "#FDE68A",
  },
  badgeSky: {
    borderColor: "rgba(14,165,233,0.42)",
    background: "rgba(14,165,233,0.12)",
    color: "#7DD3FC",
  },
  badgePurple: {
    borderColor: "rgba(168,85,247,0.42)",
    background: "rgba(168,85,247,0.12)",
    color: "#D8B4FE",
  },
  badgeGreen: {
    borderColor: "rgba(34,197,94,0.42)",
    background: "rgba(34,197,94,0.12)",
    color: "#86EFAC",
  },
  badgeRed: {
    borderColor: "rgba(239,68,68,0.42)",
    background: "rgba(239,68,68,0.12)",
    color: "#FCA5A5",
  },
  badgeMuted: {
    borderColor: "rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    color: "rgba(255,255,255,0.65)",
  },
  steps: {
    display: "grid",
    gridTemplateColumns: "repeat(5, 1fr)",
    gap: 8,
    marginTop: 18,
  },
  stepDot: {
    height: 8,
    borderRadius: 999,
  },
  infoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
    gap: 10,
    marginTop: 14,
  },
  infoBox: {
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 18,
    background: "rgba(0,0,0,0.26)",
    padding: 12,
  },
  empty: {
    border: "1px dashed rgba(255,255,255,0.16)",
    borderRadius: 30,
    background: "rgba(255,255,255,0.035)",
    padding: 28,
    textAlign: "center",
  },
};

export default function OrderStatusPage() {
  const [orders, setOrders] = useState<OrderDoc[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("fuse_session");

    if (saved) {
      try {
        const parsed = JSON.parse(saved) as { phone?: string };
        if (parsed?.phone) setSearch(parsed.phone);
      } catch {}
    }

    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((item) => ({
          ...(item.data() as Omit<OrderDoc, "documentId">),
          documentId: item.id,
        }));

        setOrders(data);
        setLoading(false);
        setError("");
      },
      (snapshotError) => {
        setOrders([]);
        setLoading(false);
        setError(snapshotError.message || "تعذر تحميل الطلبات");
      }
    );

    return () => unsubscribe();
  }, []);

  const visibleOrders = useMemo(() => {
    return orders.filter((order) => matchesSearch(order, search)).slice(0, 8);
  }, [orders, search]);

  return (
    <main dir="rtl" style={styles.page}>
      <section style={styles.shell}>
        <div style={styles.topBar}>
          <Link href="/" style={styles.pill}>
            الرئيسية
          </Link>

          <Link href="/live-orders" style={styles.pill}>
            الطلبات المباشرة
          </Link>
        </div>

        <header style={styles.hero}>
          <div style={styles.heroGrid}>
            <div style={styles.card}>
              <p style={styles.eyebrow}>حالة الطلب</p>
              <h1 style={styles.title}>
                تابع طلبك
                <br />
                <span style={styles.orange}>لحظة بلحظة</span>
              </h1>
              <p style={styles.muted}>
                اكتب رقم الهاتف المستخدم بالطلب أو رقم الطلب، وراح تظهر لك آخر حالة مباشرة.
              </p>
            </div>

            <div style={styles.card}>
              <p style={styles.statLabel}>الحالة</p>
              <p style={{ ...styles.statValue, color: "#86EFAC" }}>
                {loading ? "تحميل" : "مباشر"}
              </p>
              <p style={styles.muted}>متصل بقاعدة الطلبات</p>
            </div>
          </div>
        </header>

        <section style={styles.searchBox}>
          <label style={{ display: "grid", gap: 8 }}>
            <span style={{ fontSize: 13, color: "rgba(255,255,255,0.65)", fontWeight: 900 }}>
              رقم الهاتف أو رقم الطلب
            </span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              style={styles.input}
              placeholder="0770... أو رقم الطلب"
              dir="ltr"
            />
          </label>
        </section>

        <section style={styles.resultGrid}>
          {loading ? (
            <div style={styles.empty}>
              <h2 style={{ margin: 0 }}>جاري تحميل الطلبات...</h2>
              <p style={styles.muted}>انتظر لحظات.</p>
            </div>
          ) : error ? (
            <div style={styles.empty}>
              <h2 style={{ margin: 0, color: "#FCA5A5" }}>تعذر تحميل الطلبات</h2>
              <p style={styles.muted}>{error}</p>
            </div>
          ) : visibleOrders.length === 0 ? (
            <div style={styles.empty}>
              <h2 style={{ margin: 0 }}>ما لقينا طلب مطابق</h2>
              <p style={styles.muted}>
                تأكد من رقم الهاتف أو استخدم نفس رقم الطلب الموجود برسالة التأكيد.
              </p>
            </div>
          ) : (
            visibleOrders.map((order) => {
              const cleanStatus = normalizeStatus(order.status);
              const currentStepIndex = Math.max(0, steps.indexOf(cleanStatus));

              return (
                <article key={order.documentId} style={styles.orderCard}>
                  <div style={styles.orderTop}>
                    <div>
                      <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                        <h2 style={{ margin: 0, fontSize: 26, fontWeight: 950 }}>
                          {getRestaurant(order)}
                        </h2>

                        <span style={{ ...styles.badge, ...badgeStyle(cleanStatus) }}>
                          {cleanStatus}
                        </span>
                      </div>

                      <p style={styles.muted}>
                        {getCustomer(order)} — {formatDate(order.createdAt)}
                      </p>

                      <div style={styles.infoGrid}>
                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>الهاتف</p>
                          <p style={{ margin: "8px 0 0", direction: "ltr" }}>
                            {getPhone(order) || "—"}
                          </p>
                        </div>

                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>السائق</p>
                          <p style={{ ...styles.muted, margin: "8px 0 0" }}>
                            {order.driverName || "بانتظار السائق"}
                          </p>
                        </div>

                        <div style={styles.infoBox}>
                          <p style={styles.statLabel}>العنوان</p>
                          <p style={{ ...styles.muted, margin: "8px 0 0" }}>
                            {order.address || "بدون عنوان"}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div style={styles.totalBox}>
                      <p style={styles.statLabel}>المجموع</p>
                      <p style={{ ...styles.statValue, ...styles.orange }}>
                        {getTotal(order).toLocaleString()} د.ع
                      </p>
                      <p style={styles.muted}>
                        رقم الطلب: {order.orderId || order.documentId.slice(0, 8)}
                      </p>
                    </div>
                  </div>

                  <div style={styles.steps}>
                    {steps.map((step, index) => (
                      <div key={step}>
                        <div
                          style={{
                            ...styles.stepDot,
                            background:
                              index <= currentStepIndex ? "#FF7A00" : "rgba(255,255,255,0.12)",
                          }}
                        />

                        <p
                          style={{
                            margin: "8px 0 0",
                            color:
                              index <= currentStepIndex
                                ? "rgba(255,255,255,0.78)"
                                : "rgba(255,255,255,0.35)",
                            fontSize: 11,
                            fontWeight: 800,
                            textAlign: "center",
                          }}
                        >
                          {step}
                        </p>
                      </div>
                    ))}
                  </div>
                </article>
              );
            })
          )}
        </section>
      </section>
    </main>
  );
}
